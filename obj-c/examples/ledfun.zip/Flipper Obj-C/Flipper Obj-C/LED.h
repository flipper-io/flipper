//
//  LED.h
//  Flipper Obj-C
//
//  Created by George Morgan on 8/29/15.
//  Copyright (c) 2015 George Morgan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NSColor;

@interface LED : NSObject

@property (nonatomic) uint8_t red;
@property (nonatomic) uint8_t green;
@property (nonatomic) uint8_t blue;

+ (void)setColor:(NSColor *)color;
+ (void)setRed:(uint8_t)red green:(uint8_t)green blue:(uint8_t)blue;

@end
