//
//  LED.m
//  Flipper Obj-C
//
//  Created by George Morgan on 8/29/15.
//  Copyright (c) 2015 George Morgan. All rights reserved.
//

#import "LED.h"
#import <flipper/flipper.h>

@import AppKit;

@implementation LED

- (instancetype)init {
	if ((self = [super init])) {
		_red = 0;
		_green = 0;
		_blue = 0;
		[self reset];
	}
	return self;
}

+ (void)setRed:(uint8_t)red green:(uint8_t)green blue:(uint8_t)blue {
	led.rgb(red, green, blue);
}

+ (void)setColor:(NSColor *)color {
	color = [color colorUsingColorSpace:[NSColorSpace deviceRGBColorSpace]];
	CGFloat red, green, blue;
	[color getRed:&red green:&green blue:&blue alpha:NULL];
	[self setRed:red * 255.0 green:green * 255.0 blue:blue * 255.0];
}

- (void)setRed:(uint8_t)red {
	_red = red;
	[self reset];
}

- (void)setGreen:(uint8_t)green {
	_green = green;
	[self reset];
}

- (void)setBlue:(uint8_t)blue {
	_blue = blue;
	[self reset];
}

- (void)reset {
	[self.class setRed:self.red green:self.green blue:self.blue];
}

@end
