//
//  LEDController.swift
//  Flipper Obj-C
//
//  Created by George Morgan on 8/29/15.
//  Copyright (c) 2015 George Morgan. All rights reserved.
//

import Foundation
import AppKit

class LEDController: NSObject {
	let led = LED()
	var timer: NSTimer!
	
	override init() {
		super.init()
		timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: "change", userInfo: nil, repeats: true)
	}
	
	func startTimer() {
		NSRunLoop.mainRunLoop().addTimer(timer, forMode: NSRunLoopCommonModes)
	}
	
	func change() {
	}
	
	func randomColor() -> UInt8 {
		return UInt8(arc4random_uniform(255))
	}
}