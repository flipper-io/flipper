//
//  main.m
//  Flipper Obj-C
//
//  Created by George Morgan on 8/29/15.
//  Copyright (c) 2015 George Morgan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <flipper/flipper.h>
#import "LED.h"
#import "Flipper_Obj_C-Swift.h"
@import AppKit;

#define COLOR(x) fabs(sin(x) * 64.0)

int main(int argc, const char * argv[]) {
	@autoreleasepool {
		CGFloat r = 1.0;
		CGFloat g = 2.0;
		CGFloat b = 3.0;
		while (YES) {
			r += 0.01;
			g += 0.01;
			b += 0.01;
			[LED setRed:COLOR(r) green:COLOR(g) blue:COLOR(b)];
		}
	}
    return 0;
}
